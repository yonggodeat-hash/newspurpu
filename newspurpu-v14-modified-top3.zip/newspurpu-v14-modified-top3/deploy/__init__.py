"""CPU-only inference service for the persisted V14 model."""
