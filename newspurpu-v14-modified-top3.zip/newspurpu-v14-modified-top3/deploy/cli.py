"""python -m deploy.cli --checkpoint checkpoint --input history.json"""
import argparse
import json
import sys
from .service import Predictor, ROOT, MAX_BYTES, parse_payload


def main():
    parser = argparse.ArgumentParser(description='Return three model tickets from supplied historical draws.')
    parser.add_argument('--checkpoint', default=str(ROOT / 'checkpoint'))
    parser.add_argument('--input', default='-', help='JSON path or - for stdin')
    args = parser.parse_args()
    try:
        model = Predictor(args.checkpoint)
        if args.input == '-':
            raw = sys.stdin.buffer.read(MAX_BYTES + 1)
        else:
            with open(args.input, 'rb') as stream:
                raw = stream.read(MAX_BYTES + 1)
        result = model.predict(parse_payload(raw))
        print(json.dumps(result, allow_nan=False))
    except (ValueError, OSError, KeyError, OverflowError) as exc:
        print(json.dumps({'error': str(exc)}), file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
