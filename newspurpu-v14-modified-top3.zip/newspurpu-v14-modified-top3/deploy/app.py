"""WSGI: deploy.app:application. Development server: python -m deploy.app."""
import argparse
import json
import os
from .service import Predictor, ROOT, MAX_BYTES, parse_payload


def create_app(checkpoint):
    predictor = Predictor(checkpoint)  # Fail startup rather than serve with unverified weights.
    def application(environ, start_response):
        status = '200 OK'
        try:
            path, method = environ.get('PATH_INFO', ''), environ.get('REQUEST_METHOD', '')
            if path == '/health' and method == 'GET':
                result = {'status': 'ok', 'model': 'newspurpu', 'checkpoint_sha256': predictor.checkpoint_sha256}
            elif path == '/predict' and method == 'POST':
                if environ.get('CONTENT_TYPE', '').split(';')[0].strip().lower() != 'application/json':
                    raise ValueError('Content-Type must be application/json')
                length = environ.get('CONTENT_LENGTH', '')
                if not length.isascii() or not length.isdigit() or not 0 < int(length) <= MAX_BYTES:
                    raise ValueError('valid Content-Length in 1..1048576 required')
                raw = environ['wsgi.input'].read(int(length))
                if len(raw) != int(length):
                    raise ValueError('truncated request body')
                result = predictor.predict(parse_payload(raw))
            else:
                status, result = '404 Not Found', {'error': 'route not found'}
        except (ValueError, OverflowError) as exc:
            status, result = '400 Bad Request', {'error': str(exc)}
        except Exception:
            status, result = '500 Internal Server Error', {'error': 'inference failed'}
        body = json.dumps(result, allow_nan=False).encode()
        start_response(status, [('Content-Type', 'application/json; charset=utf-8'), ('Content-Length', str(len(body)))])
        return [body]
    return application


if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--port', type=int, default=8000)
    p.add_argument('--checkpoint', default=os.environ.get('NEWSPURPU_CHECKPOINT', str(ROOT / 'checkpoint')))
    a = p.parse_args()
    with make_server(a.host, a.port, create_app(a.checkpoint)) as server:
        server.serve_forever()
else:
    application = create_app(os.environ.get('NEWSPURPU_CHECKPOINT', str(ROOT / 'checkpoint')))
