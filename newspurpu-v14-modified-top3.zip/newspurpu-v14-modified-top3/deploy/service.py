"""Shared validation and inference; no training or historical scoring."""
import hashlib
import json
import math
from pathlib import Path

MAX_BYTES = 1024 * 1024
MAX_ROWS = 4096
ROOT = Path(__file__).resolve().parents[1]


def parse_payload(raw):
    if len(raw) > MAX_BYTES:
        raise ValueError('request exceeds 1 MiB')
    def invalid_constant(value):
        raise ValueError('non-finite JSON number')
    def unique_object(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError('duplicate JSON key')
            out[key] = value
        return out
    try:
        return json.loads(raw, parse_constant=invalid_constant, object_pairs_hook=unique_object)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError('invalid JSON') from exc


def validate(payload):
    if not isinstance(payload, dict) or set(payload) != {'history'}:
        raise ValueError('expected only history; output count is fixed at 3')
    rows = payload['history']
    if not isinstance(rows, list) or not 128 <= len(rows) <= MAX_ROWS:
        raise ValueError('history requires 128..4096 rows in chronological order')
    for row in rows:
        if not isinstance(row, list) or len(row) != 7:
            raise ValueError('each history row requires six red numbers and one blue')
        if any(type(v) not in (int, float) or not math.isfinite(v) or v != int(v) for v in row):
            raise ValueError('history numbers must be finite integers; booleans are invalid')
        if any(not 1 <= v <= 33 for v in row[:6]) or len(set(row[:6])) != 6 or not 1 <= row[6] <= 16:
            raise ValueError('red numbers must be distinct in 1..33; blue in 1..16')
    return [[int(v) for v in row] for row in rows[-128:]]


class Predictor:
    def __init__(self, checkpoint):
        import numpy as np
        from bayes_model import load_model
        checkpoint = Path(checkpoint).resolve()
        raw = (checkpoint / 'MANIFEST.json').read_bytes()
        manifest = json.loads(raw)
        for name in ('bayes_model.py', 'bayes_cb.py', 'selection.py'):
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != manifest['source_hashes'][name]:
                raise ValueError('model source hash mismatch: ' + name)
        self.model = load_model(checkpoint, 'programmed')
        t = self.model.tensors
        if set(t) != {'weight', 'bias'} or t['weight'].shape != (100, 49) or t['bias'].shape != (100,):
            raise ValueError('invalid persisted scorer shape')
        if any(a.dtype != np.float32 or not np.isfinite(a).all() for a in t.values()):
            raise ValueError('invalid persisted scorer dtype/value')
        self.checkpoint_sha256 = hashlib.sha256(raw).hexdigest()

    def predict(self, payload):
        history = validate(payload)
        law = self.model.predict(history)
        selected = law.topk(3)
        if len(selected) != 3 or len({tuple(t) for t in selected}) != 3:
            raise RuntimeError('model did not return three distinct tickets')
        tickets = []
        for ticket in selected:
            numbers = [int(v) for v in ticket]
            validate({'history': [numbers] * 128})
            probability = math.exp(law.log_prob(numbers))
            if not math.isfinite(probability) or not 0 < probability <= 1:
                raise RuntimeError('invalid model probability')
            tickets.append({'red': sorted(numbers[:6]), 'blue': numbers[6], 'model_probability': probability})
        return {'model': 'newspurpu', 'architecture': 'finite_bayesian_mixture_v14',
                'count': 3, 'tickets': tickets,
                'combined_model_probability': math.fsum(t['model_probability'] for t in tickets),
                'probability_meaning': 'Model probability of these three mutually exclusive complete draws; not an empirical winning rate.',
                'checkpoint_sha256': self.checkpoint_sha256}
