"""Engineering tests only; synthetic histories, no real draw scoring or network."""
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from .service import Predictor, parse_payload, validate

CHECKPOINT = Path(os.environ['NEWSPURPU_CHECKPOINT']).resolve()
from .app import application
FIXTURE = Path(__file__).with_name('synthetic_history.json')

class EngineeringTests(unittest.TestCase):
    def setUp(self):
        self.payload = json.loads(FIXTURE.read_text())
    def request(self, raw, path='/predict', method='POST', **kwargs):
        env = {'PATH_INFO': path, 'REQUEST_METHOD': method, 'CONTENT_TYPE': 'application/json',
               'CONTENT_LENGTH': str(len(raw)), 'wsgi.input': io.BytesIO(raw)}
        env.update(kwargs); status = []
        result = b''.join(application(env, lambda s, h: status.append(s)))
        return status[0], json.loads(result)
    def test_three_and_cli(self):
        status, result = self.request(json.dumps(self.payload).encode())
        self.assertEqual(status, '200 OK'); self.assertEqual(result['count'], 3)
        self.assertEqual(len({tuple(x['red']) + (x['blue'],) for x in result['tickets']}), 3)
        self.assertAlmostEqual(sum(x['model_probability'] for x in result['tickets']), result['combined_model_probability'])
        cp = subprocess.run([sys.executable, '-m', 'deploy.cli', '--checkpoint', str(CHECKPOINT), '--input', str(FIXTURE)], capture_output=True, check=True)
        self.assertEqual(json.loads(cp.stdout), result)
    def test_health(self):
        status, result = self.request(b'', '/health', 'GET')
        self.assertEqual(status, '200 OK'); self.assertEqual(result['status'], 'ok')
    def test_bad_inputs(self):
        for raw in (b'{', b'NaN', b'{"history":[],"history":[]}', b'\xff', b'{"history":[]}'):
            self.assertEqual(self.request(raw)[0], '400 Bad Request')
        for value in (True, 1.1, float('nan'), float('inf'), '1', 0, 34):
            p = json.loads(FIXTURE.read_text()); p['history'][0][0] = value
            self.assertEqual(self.request(json.dumps(p).encode())[0], '400 Bad Request')
        p = self.payload; p['history'][0][1] = p['history'][0][0]
        self.assertEqual(self.request(json.dumps(p).encode())[0], '400 Bad Request')
        self.assertEqual(self.request(b'{}', CONTENT_LENGTH='1048577')[0], '400 Bad Request')
        self.assertEqual(self.request(b'{}', CONTENT_LENGTH='3')[0], '400 Bad Request')
        p = json.loads(FIXTURE.read_text()); p['k'] = 2
        self.assertEqual(self.request(json.dumps(p).encode())[0], '400 Bad Request')
    def test_last128_and_integrity(self):
        model = Predictor(CHECKPOINT)
        extended = {'history': [[1,2,3,4,5,6,1]] + self.payload['history']}
        self.assertEqual(model.predict(self.payload), model.predict(extended))
        import tempfile, shutil
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            for name in ('MANIFEST.json', 'edited.npz', 'basis.npz'):
                shutil.copyfile(CHECKPOINT / name, p / name)
            import numpy as np
            with np.load(p / 'edited.npz') as z: tensors = dict(z)
            tensors['weight'] = tensors['weight'].copy(); tensors['weight'][0,0] += 1
            np.savez(p / 'edited.npz', **tensors)
            with self.assertRaisesRegex(ValueError, 'hash mismatch'): Predictor(p)

if __name__ == '__main__': unittest.main()
