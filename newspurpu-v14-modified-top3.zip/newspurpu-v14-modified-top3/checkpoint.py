"""Deterministic direct weight construction; no data, training or optimizer."""
import json,hashlib
from pathlib import Path
import numpy as np
from bayes_model import make_basis,sha,load_model

def build_checkpoint(path):
 p=Path(path);p.mkdir(parents=True,exist_ok=True)
 cfg=Path(__file__).with_name('CONFIG.json');config=json.loads(cfg.read_text());basis=make_basis()
 base={'weight':np.zeros((100,49),np.float32),'bias':np.zeros(100,np.float32)}
 edit={k:v.copy() for k,v in base.items()}
 edit['weight'][:67,:33]=basis['red_theta'];edit['weight'][67:,33:]=basis['blue_theta']
 priors=[]
 for n,key,sl in [(33,'red_logZ',slice(0,67)),(16,'blue_logZ',slice(67,100))]:
  prior=np.r_[.9,np.full(2*n,.1/(2*n))];priors.append(prior)
  edit['bias'][sl]=np.log(prior)-128*(basis[key]-basis[key][0])
 basis['red_prior'],basis['blue_prior']=priors
 rng=np.random.default_rng(config['random_seed']);random={k:v.copy() for k,v in base.items()}
 for k,v in edit.items():
  support=v!=0;noise=rng.normal(size=support.sum());noise*=np.linalg.norm(v.astype(float))/np.linalg.norm(noise);random[k][support]=noise.astype(np.float32)
 tensors={'base':base,'edited':edit,'random':random,'delta':{k:edit[k]-base[k] for k in base}}
 for name,t in tensors.items():np.savez(p/(name+'.npz'),**t)
 np.savez(p/'basis.npz',**basis);(p/'CONFIG.json').write_bytes(cfg.read_bytes())
 metrics={}
 for name,t in tensors.items():
  metrics[name]={k:dict(shape=list(v.shape),dtype=str(v.dtype),changed=int(np.count_nonzero(v-base[k])),l2=float(np.linalg.norm((v-base[k]).astype(float)))) for k,v in t.items()}
 sources={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ['bayes_model.py','bayes_cb.py','checkpoint.py','CONFIG.json','selection.py']}
 m=dict(version=config['version'],parameter_count=5000,training_calls=0,neural_optimizer_calls=0,prior_estimated_from_data=False,source_hashes=sources,tensor_hashes={n:{k:sha(v) for k,v in t.items()} for n,t in tensors.items()},basis_hashes={k:sha(v) for k,v in basis.items()},metrics=metrics,axes={'weight':'component100,input_count49','bias':'component100'},formula='W rows theta; b=logprior-128*(logZtheta-logZuniform); dense FP32 scorer, F64 softmax/readout',limits='new model; no TimesFM weight edits; rolling counts discard temporal order')
 m['map_numerics']={'rule':'lexicographically smallest red within 1e-12 log mass of optimum; blue within 1e-12; first ticket joint bound2e-12 plus floating rounding','weights_and_basis_unchanged':True}
 m['topk_policy']='1..3 distinct tickets; map first unchanged; factor budgets1e-12 each plus cross-product budget2e-12; subsequent tickets remaining-global bound4e-12 plus rounding; not diverse red-ball constraint'
 (p/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
 for arm in ['uniform_base','programmed','random_matched','mean_theta_plugin']:load_model(p,arm)
 return m

class CheckpointSession:
 def __init__(self,path):self.path=Path(path);self.model=load_model(path,'uniform_base')
 def apply(self,arm):
  if self.model.arm!='uniform_base':raise RuntimeError('restore before next apply')
  self.model=load_model(self.path,arm);return self.model
 def restore(self):
  self.model=load_model(self.path,'uniform_base');return {k:sha(v) for k,v in self.model.tensors.items()}

if __name__=='__main__':
 import sys
 build_checkpoint(sys.argv[1])
