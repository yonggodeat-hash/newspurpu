# 来源和依赖

当前推理模型为 futura/newspurpu 项目的有限贝叶斯概率混合模型，参数由本项目直接构造。运行代码不加载 TimesFM-3，也不包含 TimesFM-3 模型权重。此前项目对 TimesFM 的来源和许可记录仍留在原研究项目中，本包不改变其内容。

唯一必需第三方运行库是 NumPy 1.26.4（BSD-3-Clause）：https://numpy.org/doc/1.26/license.html 。本包提供依赖声明，不捆绑第三方安装包；安装后应保留库自带声明。附带 Dockerfile 引用官方 Python 容器镜像，构建时由包管理器安装依赖。本包不另行为项目代码授予新的开源许可证。
