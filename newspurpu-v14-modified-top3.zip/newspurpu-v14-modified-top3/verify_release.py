"""Verify all packaged file bytes without importing the model or dependencies."""
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'RELEASE_MANIFEST.json').read_text())
    for name, expected in manifest['files'].items():
        path = root / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
            raise SystemExit('Integrity check failed: ' + name)
    print(json.dumps({'status': 'passed', 'files_verified': len(manifest['files']),
                      'model': 'newspurpu', 'default_output_count': 3}))


if __name__ == '__main__':
    main()
