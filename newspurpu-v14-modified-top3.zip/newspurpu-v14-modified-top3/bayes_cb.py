"""Exact conditional-Bernoulli fixed-six law and independent blue categorical."""
import numpy as np

def logsumexp(a):
 a=np.asarray(a,float);v=float(np.max(a))
 return float(v+np.log(np.exp(a-v).sum())) if np.isfinite(v) else -np.inf

# Numerical MAP policy: lexicographically smallest subset whose additive
# objective is within the supplied total budget of the exact floating optimum.
MAP_LOG_TOL = 1e-12

def lex_near_max(values, k, budget):
 values=np.asarray(values,np.float64)
 optimum=float(np.sort(values)[-k:].sum())
 selected=[];start=0;partial=0.
 for position in range(k):
  remaining=k-position-1
  for i in range(start,len(values)-remaining):
   tail=0. if remaining==0 else float(np.sort(values[i+1:])[-remaining:].sum())
   if partial+values[i]+tail >= optimum-budget:
    selected.append(i);partial+=values[i];start=i+1;break
  else:raise ArithmeticError('MAP tolerance selection failed')
 return selected

class Distribution:
 def __init__(self,theta):
  theta=np.asarray(theta,np.float64)
  if theta.shape!=(49,) or not np.isfinite(theta).all():raise ValueError('finite 49 logits required')
  self.theta=theta.copy();self.red_theta=theta[:33].copy();self.blue_theta=theta[33:].copy()
  # A shared red logit offset cancels in fixed-cardinality probabilities.
  offset=float(np.max(self.red_theta));t=self.red_theta-offset;k=6;n=33
  prefix=np.full((k+1,n+1),-np.inf);prefix[0]=0.
  for i in range(1,n+1):
   for r in range(1,min(k,i)+1):prefix[r,i]=np.logaddexp(prefix[r,i-1],t[i-1]+prefix[r-1,i-1])
  suffix=np.full((k+1,n+1),-np.inf);suffix[0]=0.
  for i in range(n-1,-1,-1):
   for r in range(1,min(k,n-i)+1):suffix[r,i]=np.logaddexp(suffix[r,i+1],t[i]+suffix[r-1,i+1])
  z=float(prefix[k,n]);self.red_logZ=float(z+k*offset);self.blue_logZ=logsumexp(self.blue_theta)
  self.blue_probs=np.exp(self.blue_theta-self.blue_logZ)
  self.red_rank_marginals=np.zeros((6,33))
  for rank in range(6):
   for i in range(33):self.red_rank_marginals[rank,i]=np.exp(t[i]+prefix[rank,i]+suffix[5-rank,i+1]-z)
  self.red_inclusion=self.red_rank_marginals.sum(0)
  self._prefix=prefix;self._centered_red=t
  if not np.allclose(self.red_rank_marginals.sum(1),1.,rtol=0,atol=1e-12) or abs(self.blue_probs.sum()-1)>1e-12:raise ArithmeticError('DP normalization failed')
  self.MAP=[i+1 for i in lex_near_max(self.red_theta,6,MAP_LOG_TOL)]+[lex_near_max(self.blue_theta,1,MAP_LOG_TOL)[0]+1]
 def log_prob(self,ticket):
  a=np.asarray(ticket)
  if a.shape!=(7,) or not np.isfinite(a).all() or np.any(a!=np.floor(a)) or np.any(np.diff(np.sort(a[:6]))<=0) or np.any(a[:6]<1) or np.any(a[:6]>33) or not 1<=a[6]<=16:return -np.inf
  y=a.astype(int);y[:6]=np.sort(y[:6]);return float(self.red_theta[y[:6]-1].sum()-self.red_logZ+self.blue_theta[y[6]-1]-self.blue_logZ)
 def nll(self,ticket):return -self.log_prob(ticket)
 def map(self):return self.MAP.copy()
 def topk(self,k=3):
  from selection import joint_topk
  return joint_topk(self,self.red_theta,MAP_LOG_TOL,k)
 def cross_entropy(self,other):
  return float(other.red_logZ-self.red_inclusion@other.red_theta+other.blue_logZ-self.blue_probs@other.blue_theta)
 def kl(self,other):return self.cross_entropy(other)-self.cross_entropy(self)
 def sample(self,rng,size=None):
  def one():
   remaining=6;selected=[]
   for i in range(32,-1,-1):
    if remaining==0:break
    if remaining==i+1:chosen=True
    else:
     prob=float(np.exp(self._centered_red[i]+self._prefix[remaining-1,i]-self._prefix[remaining,i+1]))
     if not -1e-12<=prob<=1+1e-12:raise ArithmeticError('invalid conditional sample probability')
     chosen=rng.random()<min(1.,max(0.,prob))
    if chosen:selected.append(i+1);remaining-=1
   if remaining:raise ArithmeticError('cardinality sampling failed')
   return np.asarray(sorted(selected)+[int(rng.choice(16,p=self.blue_probs))+1],dtype=np.int64)
  return one() if size is None else np.asarray([one() for _ in range(int(size))])
 def summary(self):
  return {'theta':self.theta.tolist(),'red_inclusion':self.red_inclusion.tolist(),'red_rank_marginals':self.red_rank_marginals.tolist(),'blue_probs':self.blue_probs.tolist(),'MAP':self.MAP,'red_logZ':self.red_logZ,'blue_logZ':self.blue_logZ,'red_blue_conditionally_independent':True}
