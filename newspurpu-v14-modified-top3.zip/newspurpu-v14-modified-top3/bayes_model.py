"""Fixed finite Bayes model: actual saved FP32 scorer and exact mixture readout."""
import json, hashlib
from pathlib import Path
import numpy as np
from bayes_cb import Distribution, logsumexp, lex_near_max, MAP_LOG_TOL

def sha(a):
 a=np.ascontiguousarray(a);return hashlib.sha256(a.tobytes()).hexdigest()

def features(history):
 a=np.asarray(history)
 if a.ndim!=2 or a.shape[1]!=7 or len(a)<128:raise ValueError('history >=128 x7 required')
 a=a[-128:]
 if not np.isfinite(a).all() or np.any(a!=np.floor(a)):raise ValueError('integer history required')
 r=np.sort(a[:,:6].astype(int),axis=1);b=a[:,6].astype(int)
 if np.any(r<1) or np.any(r>33) or np.any(np.diff(r,axis=1)<=0) or np.any(b<1) or np.any(b>16):raise ValueError('illegal ticket')
 return np.concatenate([np.bincount(r.ravel(),minlength=34)[1:],np.bincount(b,minlength=17)[1:]]).astype(np.float32)

def make_basis():
 def grid(n):
  out=[np.zeros(n)]
  for i in range(n):
   v=np.eye(n)[i]-1/n;out.extend([.5*v,-.5*v])
  return np.asarray(out)
 red=grid(33);blue=grid(16)
 components=[Distribution(np.r_[v,np.zeros(16)]) for v in red]
 bz=np.asarray([logsumexp(v) for v in blue])
 return dict(red_theta=red,blue_theta=blue,red_logZ=np.asarray([d.red_logZ for d in components]),blue_logZ=bz,
 red_inclusion=np.asarray([d.red_inclusion for d in components]),red_rank=np.asarray([d.red_rank_marginals for d in components]),blue_probs=np.exp(blue-bz[:,None]))

class MixtureDistribution:
 def __init__(self,rw,bw,basis):
  self.red_weights=np.asarray(rw,float);self.blue_weights=np.asarray(bw,float);self.basis=basis
  self.red_inclusion=self.red_weights@basis['red_inclusion'];self.red_rank_marginals=np.einsum('i,ijk->jk',self.red_weights,basis['red_rank'])
  self.blue_probs=self.blue_weights@basis['blue_probs']
  # Exact affine set mass for single-coordinate components, zero-sum gauge included.
  coeff=np.zeros(33)
  for i in range(33):
   for sign,idx in [(1,1+2*i),(-1,2+2*i)]:
    const=np.exp(-sign*.5*6/33-basis['red_logZ'][idx])
    coeff[i]+=self.red_weights[idx]*const*np.expm1(sign*.5)
  best=np.argsort(-coeff,kind='stable')[:6]+1
  best_mass=np.exp(self.red_log_prob(best))
  # A total additive mass budget gives <=1e-12 red log-probability regret.
  red=lex_near_max(coeff,6,best_mass*(-np.expm1(-MAP_LOG_TOL)))
  blue=lex_near_max(np.log(self.blue_probs),1,MAP_LOG_TOL)[0]
  self.MAP=[i+1 for i in red]+[blue+1]
  self._topk_coeff=coeff;self._topk_budget=best_mass*(-np.expm1(-MAP_LOG_TOL))
 def red_log_prob(self,red):
  a=np.asarray(red)
  if a.shape!=(6,) or not np.isfinite(a).all() or np.any(a!=np.floor(a)) or np.any(a<1) or np.any(a>33) or len(np.unique(a))!=6:return -np.inf
  logits=self.basis['red_theta'][:,a.astype(int)-1].sum(1)-self.basis['red_logZ']
  with np.errstate(divide='ignore'):return logsumexp(np.log(self.red_weights)+logits)
 def log_prob(self,ticket):
  a=np.asarray(ticket)
  if a.shape!=(7,) or not np.isfinite(a).all() or a[6]!=int(a[6]) or not 1<=a[6]<=16:return -np.inf
  return float(self.red_log_prob(a[:6])+np.log(self.blue_probs[int(a[6])-1]))
 def nll(self,ticket):return -self.log_prob(ticket)
 def map(self):return self.MAP.copy()
 def topk(self,k=3):
  from selection import joint_topk
  return joint_topk(self,self._topk_coeff,self._topk_budget,k)
 def sample(self,rng,size=None):
  def one():
   j=rng.choice(67,p=self.red_weights);red=Distribution(np.r_[self.basis['red_theta'][j],np.zeros(16)]).sample(rng)[:6]
   return np.r_[red,rng.choice(16,p=self.blue_probs)+1]
  return one() if size is None else np.asarray([one() for _ in range(size)])
 def summary(self):
  return dict(red_weights=self.red_weights.tolist(),blue_weights=self.blue_weights.tolist(),red_inclusion=self.red_inclusion.tolist(),blue_probs=self.blue_probs.tolist(),MAP=self.MAP,distribution='finite CB mixture times independent categorical mixture')

class Model:
 def __init__(self,tensors,basis,arm='programmed'):
  self.tensors={k:np.array(v,copy=True) for k,v in tensors.items()};self.basis=basis;self.arm=arm
 def forward(self,counts):
  x=np.asarray(counts,np.float32)
  if x.shape!=(49,) or not np.isfinite(x).all():raise ValueError('finite count49 required')
  scores=self.tensors['weight']@x+self.tensors['bias']
  def soft(v):
   # scorer is FP32; probability normalization F64 for exact DP stability.
   v=v.astype(np.float64);return np.exp(v-logsumexp(v))
  return dict(scores=scores,red_weights=soft(scores[:67]),blue_weights=soft(scores[67:]))
 def predict(self,history):
  out=self.forward(features(history))
  if self.arm=='mean_theta_plugin':return Distribution(np.r_[out['red_weights']@self.basis['red_theta'],out['blue_weights']@self.basis['blue_theta']])
  return MixtureDistribution(out['red_weights'],out['blue_weights'],self.basis)

def load_model(checkpoint,arm='programmed'):
 p=Path(checkpoint);m=json.loads((p/'MANIFEST.json').read_text())
 if arm not in ['uniform_base','programmed','random_matched','mean_theta_plugin']:raise ValueError('unknown arm')
 name={'uniform_base':'base','programmed':'edited','random_matched':'random','mean_theta_plugin':'edited'}[arm]
 with np.load(p/(name+'.npz'),allow_pickle=False) as z:t={k:z[k] for k in z.files}
 with np.load(p/'basis.npz',allow_pickle=False) as z:b={k:z[k] for k in z.files}
 for k,v in t.items():
  if sha(v)!=m['tensor_hashes'][name][k]:raise ValueError('tensor hash mismatch')
 for k,v in b.items():
  if sha(v)!=m['basis_hashes'][k]:raise ValueError('basis hash mismatch')
 return Model(t,b,arm)
