# newspurpu — 修改后权重与三组号码推理包

本包默认加载已修改的 `checkpoint/edited.npz`，每次返回 **3 组互不重复的合法双色球完整组合**。包含运行代码、全部必需模型参数与配置、CLI、HTTP 接口及工程检查记录。无需下载其他模型，也无需 GPU。

这是用户选定的“假设二：有限贝叶斯概率混合”小型模型，具有 5,000 个评分器参数，其中 2,790 个已直接改写；不是 TimesFM-3 全量权重。固定概率基底 `basis.npz` 也是推理必需文件，请一并保留。探索已停止，本次没有继续训练或真实开奖收益实验。

## 快速运行

解压后进入本目录。使用 Python 3.10 或 3.11：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m deploy.cli --input deploy/synthetic_history.json
```

示例文件是合成数据，仅用于确认安装成功，不是下一期实际推荐。

真实请求保存为 `history.json`，格式如下；`history` 至少需要 128 行，不能只提供示例中的一行：

```json
{"history": [[1, 5, 11, 16, 23, 32, 8]]}
```

每行前六项是不同的红球（1–33），最后一项为蓝球（1–16）；按开奖时间从旧到新排列，只放预测截止时已公布的开奖。最多 4,096 行，模型使用末尾 128 行。接口不自动联网抓取数据。

```bash
python -m deploy.cli --input history.json
```

## HTTP 接口

```bash
python -m deploy.app --checkpoint checkpoint --host 127.0.0.1 --port 8000
curl http://127.0.0.1:8000/health
curl -H 'Content-Type: application/json' --data-binary @history.json http://127.0.0.1:8000/predict
```

响应含 `model`、`count: 3`、`tickets`、`combined_model_probability` 和 checkpoint 哈希。每组包含 `red`、`blue`、`model_probability`。三组指完整组合不同，红球可以重叠；采用模型联合概率排序，没有另加红球分散规则。输入不接受覆盖组数的 `k` 参数。

`model_probability` 是模型对完整开奖结果的估计；三组的总概率是这三个互斥完整结果的模型概率之和，不是实测中奖率或中任意奖的概率。默认模型在已知偏差测试中的增益低于预定门槛，尚未证实真实彩票预测优势；详情保留在 `evidence/AUDIT.md`。

内置服务器用于单进程本地/内部试运行。正式托管入口为标准 WSGI `deploy.app:application`，可由部署平台的 WSGI 网关加载；checkpoint 路径由 `NEWSPURPU_CHECKPOINT` 设置。附带 Dockerfile 使用同一内部试运行服务器，镜像尚未在本机构建验证。

```bash
docker build -t newspurpu:v14 .
docker run --rm -p 127.0.0.1:8000:8000 newspurpu:v14
```

## 文件完整性与检查

```bash
python verify_release.py
NEWSPURPU_CHECKPOINT=checkpoint python -m unittest deploy.test_service -v
```

服务启动核验实际权重、概率基底和推理源码。`checkpoint/MANIFEST.json` 原样保留历史研究臂的元数据，但本包仅包含并启用修改后的 `programmed` 臂，未附原始、随机或差分控制权重。不要重建或覆盖 `checkpoint`；部署直接加载现有参数。

三组解码只改变输出选择，不改变模型概率或参数。数值并列按固定词典序处理；第一组保留旧 MAP，后续组相对剩余最优联合对数概率的保守容差为 4×10⁻¹²，另计浮点舍入。

本地已验证环境：Python 3.10.6、NumPy 1.26.4、CPU。交付工程检查见 `evidence/RELEASE_VERIFICATION.json`。本包不包含历史项目归档、虚拟环境或云端 TimesFM 大权重。
