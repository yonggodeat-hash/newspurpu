"""Bounded exact additive subset search with declared numerical tie budgets."""
import numpy as np

def subset_topk(values,count,k,budget=0.):
 v=np.asarray(values,float);n=len(v)
 # DP retains exact top k completions, enough to find the maximum after
 # excluding at most k-1 previously returned sets (including near ties).
 dp=[[] for _ in range(count+1)];dp[0]=[(0.,())]
 for i,x in enumerate(v):
  for r in range(min(i+1,count),0,-1):
   pool=dp[r]+[(s+x,t+(i,)) for s,t in dp[r-1]]
   dp[r]=sorted(pool,key=lambda z:(-z[0],z[1]))[:k]
 maxima=dp[count];banned=set();out=[]
 suffix=np.full((n+1,count+1),-np.inf);suffix[:,0]=0
 for i in range(n-1,-1,-1):
  for r in range(1,count+1):suffix[i,r]=max(suffix[i+1,r],v[i]+suffix[i+1,r-1])
 for _ in range(k):
  candidates=[s for s,t in maxima if t not in banned]
  if not candidates:break
  threshold=max(candidates)-budget
  def visit(start,left,total,t):
   if left==0:return t if total>=threshold and t not in banned else None
   for i in range(start,n-left+1):
    if total+v[i]+suffix[i+1,left-1]>=threshold:
     found=visit(i+1,left-1,total+v[i],t+(i,))
     if found is not None:return found
   return None
  chosen=visit(0,count,0.,())
  if chosen is None:raise ArithmeticError('subset numerical threshold failure')
  out.append(chosen);banned.add(chosen)
 return out

def joint_topk(distribution,values,budget,k=3):
 if isinstance(k,bool) or not isinstance(k,(int,np.integer)) or not 1<=k<=3:raise ValueError('topk supports integer 1..3')
 reds=subset_topk(values,6,k,budget)
 blues=subset_topk(np.log(distribution.blue_probs),1,k,1e-12)
 # Without ties, top-k joint must use top-k from each independent factor:
 # any lower component has k better tickets sharing its other component.
 # With the declared per-factor near-tie ordering, return a numerical near-topk.
 pool=[list(i+1 for i in r)+[b[0]+1] for r in reds for b in blues]
 # Preserve the already published MAP API exactly as the first result.
 first=distribution.map();pool=[p for p in pool if p!=first];out=[first]
 while len(out)<k:
  scores=[distribution.log_prob(p) for p in pool];best=max(scores)
  chosen=min(p for p,s in zip(pool,scores) if s>=best-2e-12)
  out.append(chosen);pool.remove(chosen)
 return out
